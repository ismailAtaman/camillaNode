class camillaDSP {
    server='';
    port='';
    version='';    
    #WS;

    constructor () {

    }

  
    
    async uploadConfigJSON(configJSON) {}
    async downloadConfigJSON() {}
    async getVersion() {}
    async getState() {}
    async GetPlaybackSignalPeak() {}
    async GetPlaybackSignalRms() {}
    async GetClippedSamples() {}
    stop() {}
    Reload() {}
    

    

}
